iA Writer Duospace comes bundled with [iA Writer for Mac and iOS](https://ia.net/writer/buy/)

For in depth explanation of iA Writer Duospace please read our [blog entry](http://ia.net/topics/in-search-of-the-perfect-writing-font/)

This is a modification of IBM's Plex font. 
The upstream project is [here](https://github.com/IBM/type)

As required by IBM, we named it differently. 
Please read the licensing file before working with it. 

If you fork or reuse our version, please reference us, too.
