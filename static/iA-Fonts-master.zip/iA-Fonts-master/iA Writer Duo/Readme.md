iA Writer Duo comes bundled with [iA Writer for Mac and iOS](https://ia.net/writer/)

For in depth explanation of iA Writer Mono, Duo, and Quattro please read our [blog entry on Duospace](http://ia.net/topics/in-search-of-the-perfect-writing-font/) and on [iA Writer Mono, Duo, and Quattro](https://ia.net/writer/topics/a-typographic-christmas)

This is a modification of IBM's Plex font. 
The upstream project is [here](https://github.com/IBM/type)
Please read the licensing file before working with it. 

If you fork or use our fonts, please reference iA Writer clearly.
