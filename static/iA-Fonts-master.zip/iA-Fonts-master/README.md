# iA-Fonts
These are fonts from iA. Please read the licensing files before using them in any way.
